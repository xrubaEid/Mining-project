```R
library(dplyr)
iris

```

    
    Attaching package: 'dplyr'
    
    The following objects are masked from 'package:stats':
    
        filter, lag
    
    The following objects are masked from 'package:base':
    
        intersect, setdiff, setequal, union
    
    


<table>
<thead><tr><th scope=col>Sepal.Length</th><th scope=col>Sepal.Width</th><th scope=col>Petal.Length</th><th scope=col>Petal.Width</th><th scope=col>Species</th></tr></thead>
<tbody>
	<tr><td>5.1   </td><td>3.5   </td><td>1.4   </td><td>0.2   </td><td>setosa</td></tr>
	<tr><td>4.9   </td><td>3.0   </td><td>1.4   </td><td>0.2   </td><td>setosa</td></tr>
	<tr><td>4.7   </td><td>3.2   </td><td>1.3   </td><td>0.2   </td><td>setosa</td></tr>
	<tr><td>4.6   </td><td>3.1   </td><td>1.5   </td><td>0.2   </td><td>setosa</td></tr>
	<tr><td>5.0   </td><td>3.6   </td><td>1.4   </td><td>0.2   </td><td>setosa</td></tr>
	<tr><td>5.4   </td><td>3.9   </td><td>1.7   </td><td>0.4   </td><td>setosa</td></tr>
	<tr><td>4.6   </td><td>3.4   </td><td>1.4   </td><td>0.3   </td><td>setosa</td></tr>
	<tr><td>5.0   </td><td>3.4   </td><td>1.5   </td><td>0.2   </td><td>setosa</td></tr>
	<tr><td>4.4   </td><td>2.9   </td><td>1.4   </td><td>0.2   </td><td>setosa</td></tr>
	<tr><td>4.9   </td><td>3.1   </td><td>1.5   </td><td>0.1   </td><td>setosa</td></tr>
	<tr><td>5.4   </td><td>3.7   </td><td>1.5   </td><td>0.2   </td><td>setosa</td></tr>
	<tr><td>4.8   </td><td>3.4   </td><td>1.6   </td><td>0.2   </td><td>setosa</td></tr>
	<tr><td>4.8   </td><td>3.0   </td><td>1.4   </td><td>0.1   </td><td>setosa</td></tr>
	<tr><td>4.3   </td><td>3.0   </td><td>1.1   </td><td>0.1   </td><td>setosa</td></tr>
	<tr><td>5.8   </td><td>4.0   </td><td>1.2   </td><td>0.2   </td><td>setosa</td></tr>
	<tr><td>5.7   </td><td>4.4   </td><td>1.5   </td><td>0.4   </td><td>setosa</td></tr>
	<tr><td>5.4   </td><td>3.9   </td><td>1.3   </td><td>0.4   </td><td>setosa</td></tr>
	<tr><td>5.1   </td><td>3.5   </td><td>1.4   </td><td>0.3   </td><td>setosa</td></tr>
	<tr><td>5.7   </td><td>3.8   </td><td>1.7   </td><td>0.3   </td><td>setosa</td></tr>
	<tr><td>5.1   </td><td>3.8   </td><td>1.5   </td><td>0.3   </td><td>setosa</td></tr>
	<tr><td>5.4   </td><td>3.4   </td><td>1.7   </td><td>0.2   </td><td>setosa</td></tr>
	<tr><td>5.1   </td><td>3.7   </td><td>1.5   </td><td>0.4   </td><td>setosa</td></tr>
	<tr><td>4.6   </td><td>3.6   </td><td>1.0   </td><td>0.2   </td><td>setosa</td></tr>
	<tr><td>5.1   </td><td>3.3   </td><td>1.7   </td><td>0.5   </td><td>setosa</td></tr>
	<tr><td>4.8   </td><td>3.4   </td><td>1.9   </td><td>0.2   </td><td>setosa</td></tr>
	<tr><td>5.0   </td><td>3.0   </td><td>1.6   </td><td>0.2   </td><td>setosa</td></tr>
	<tr><td>5.0   </td><td>3.4   </td><td>1.6   </td><td>0.4   </td><td>setosa</td></tr>
	<tr><td>5.2   </td><td>3.5   </td><td>1.5   </td><td>0.2   </td><td>setosa</td></tr>
	<tr><td>5.2   </td><td>3.4   </td><td>1.4   </td><td>0.2   </td><td>setosa</td></tr>
	<tr><td>4.7   </td><td>3.2   </td><td>1.6   </td><td>0.2   </td><td>setosa</td></tr>
	<tr><td>...</td><td>...</td><td>...</td><td>...</td><td>...</td></tr>
	<tr><td>6.9      </td><td>3.2      </td><td>5.7      </td><td>2.3      </td><td>virginica</td></tr>
	<tr><td>5.6      </td><td>2.8      </td><td>4.9      </td><td>2.0      </td><td>virginica</td></tr>
	<tr><td>7.7      </td><td>2.8      </td><td>6.7      </td><td>2.0      </td><td>virginica</td></tr>
	<tr><td>6.3      </td><td>2.7      </td><td>4.9      </td><td>1.8      </td><td>virginica</td></tr>
	<tr><td>6.7      </td><td>3.3      </td><td>5.7      </td><td>2.1      </td><td>virginica</td></tr>
	<tr><td>7.2      </td><td>3.2      </td><td>6.0      </td><td>1.8      </td><td>virginica</td></tr>
	<tr><td>6.2      </td><td>2.8      </td><td>4.8      </td><td>1.8      </td><td>virginica</td></tr>
	<tr><td>6.1      </td><td>3.0      </td><td>4.9      </td><td>1.8      </td><td>virginica</td></tr>
	<tr><td>6.4      </td><td>2.8      </td><td>5.6      </td><td>2.1      </td><td>virginica</td></tr>
	<tr><td>7.2      </td><td>3.0      </td><td>5.8      </td><td>1.6      </td><td>virginica</td></tr>
	<tr><td>7.4      </td><td>2.8      </td><td>6.1      </td><td>1.9      </td><td>virginica</td></tr>
	<tr><td>7.9      </td><td>3.8      </td><td>6.4      </td><td>2.0      </td><td>virginica</td></tr>
	<tr><td>6.4      </td><td>2.8      </td><td>5.6      </td><td>2.2      </td><td>virginica</td></tr>
	<tr><td>6.3      </td><td>2.8      </td><td>5.1      </td><td>1.5      </td><td>virginica</td></tr>
	<tr><td>6.1      </td><td>2.6      </td><td>5.6      </td><td>1.4      </td><td>virginica</td></tr>
	<tr><td>7.7      </td><td>3.0      </td><td>6.1      </td><td>2.3      </td><td>virginica</td></tr>
	<tr><td>6.3      </td><td>3.4      </td><td>5.6      </td><td>2.4      </td><td>virginica</td></tr>
	<tr><td>6.4      </td><td>3.1      </td><td>5.5      </td><td>1.8      </td><td>virginica</td></tr>
	<tr><td>6.0      </td><td>3.0      </td><td>4.8      </td><td>1.8      </td><td>virginica</td></tr>
	<tr><td>6.9      </td><td>3.1      </td><td>5.4      </td><td>2.1      </td><td>virginica</td></tr>
	<tr><td>6.7      </td><td>3.1      </td><td>5.6      </td><td>2.4      </td><td>virginica</td></tr>
	<tr><td>6.9      </td><td>3.1      </td><td>5.1      </td><td>2.3      </td><td>virginica</td></tr>
	<tr><td>5.8      </td><td>2.7      </td><td>5.1      </td><td>1.9      </td><td>virginica</td></tr>
	<tr><td>6.8      </td><td>3.2      </td><td>5.9      </td><td>2.3      </td><td>virginica</td></tr>
	<tr><td>6.7      </td><td>3.3      </td><td>5.7      </td><td>2.5      </td><td>virginica</td></tr>
	<tr><td>6.7      </td><td>3.0      </td><td>5.2      </td><td>2.3      </td><td>virginica</td></tr>
	<tr><td>6.3      </td><td>2.5      </td><td>5.0      </td><td>1.9      </td><td>virginica</td></tr>
	<tr><td>6.5      </td><td>3.0      </td><td>5.2      </td><td>2.0      </td><td>virginica</td></tr>
	<tr><td>6.2      </td><td>3.4      </td><td>5.4      </td><td>2.3      </td><td>virginica</td></tr>
	<tr><td>5.9      </td><td>3.0      </td><td>5.1      </td><td>1.8      </td><td>virginica</td></tr>
</tbody>
</table>




```R
library(ggplot2)
ggplot(data=iris, aes(x=Sepal.Length, y=Sepal.Width, color=Species)) + geom_point(size=3)

```

    Registered S3 methods overwritten by 'ggplot2':
      method         from 
      [.quosures     rlang
      c.quosures     rlang
      print.quosures rlang
    


    
![png](output_1_1.png)
    



```R

```
